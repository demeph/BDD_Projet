INSERT INTO L3_35.Client Values (75, 'jehanno', 'clement');

UPDATE L3_35.Acteur
SET prenomA = 'henry'
WHERE idAct = 1;

DELETE L3_35.Film;

SELECT * FROM L3_35.Salle;
