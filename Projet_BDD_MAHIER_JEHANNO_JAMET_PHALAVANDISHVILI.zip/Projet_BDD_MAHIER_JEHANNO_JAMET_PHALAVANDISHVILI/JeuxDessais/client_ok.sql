SELECT * FROM L3_35.Casting
WHERE idFilm = 1;

SELECT * FROM L3_35.Realisateur
WHERE idReal = 1;
