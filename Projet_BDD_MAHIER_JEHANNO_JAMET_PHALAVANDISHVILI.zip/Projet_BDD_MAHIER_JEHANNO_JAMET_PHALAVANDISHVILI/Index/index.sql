CREATE INDEX indexTitreFilm ON Film (nomFilm);
CREATE INDEX indexVilleCinema ON Cinema (ville);
